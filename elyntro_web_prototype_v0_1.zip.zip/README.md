# Elyntro Web Prototype 0.2

This is a minimal web shell around the supplied Elyntro Engine v6.2.0. It uses the engine's CognitiveLoop, RuleBasedPlanner, registered handlers, SQLite task store, and independent EvidenceVerifier. Groq chat completions are used for the analyze handler when GROQ_API_KEY is configured. If the key is absent or the provider fails, the app records the failure and falls back to a deterministic status artifact. Web search, image/audio/video generation, and computer-use providers remain unconnected. Set GROQ_MODEL optionally; default: llama-3.3-70b-versatile.

## Groq setup

Set `GROQ_API_KEY` in the hosting provider secret/environment settings. Never commit it to Git. Optional `GROQ_MODEL` defaults to `llama-3.3-70b-versatile`. The health endpoint reports whether the key is present, not whether the key is valid.

## Local run (Python 3.11+)

1. Extract `elyntro_web_prototype_v0_1.zip`.
2. Extract `elyntro_engine_v6_2_0.zip` into the same directory.
3. `pip install -r requirements.txt`
4. `PYTHONPATH=elyntro-engine-v6.2.0 python app.py`
5. Open `http://127.0.0.1:5000`.

## Render deployment from a Git repository containing only the outer ZIP

Build command:
`python -c "import zipfile; zipfile.ZipFile('elyntro_web_prototype_v0_1.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt`

Start command:
`PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app`

Health check path: `/api/health`.

The free hosting tier can sleep and its filesystem may be ephemeral; this is a prototype, not production deployment. Do not put secrets in the repository. Do not use the demo with sensitive personal information.
