# Elyntro Web Prototype 0.1

This is a minimal web shell around the supplied Elyntro Engine v6.2.0. It uses the engine's CognitiveLoop, RuleBasedPlanner, registered handlers, SQLite task store, and independent EvidenceVerifier. The generated artefacts are deterministic templates; no LLM, web search, image/audio/video generation, or computer-use provider is connected.

## Local run (Python 3.11+)

1. Extract `elyntro_web_prototype_v0_1.zip`.
2. Extract `elyntro_engine_v6_2_0.zip` into the same directory.
3. `pip install -r requirements.txt`
4. `PYTHONPATH=elyntro-engine-v6.2.0 python app.py`
5. Open `http://127.0.0.1:5000`.

## Render deployment from a Git repository containing only the outer ZIP

Build command:
`unzip -o elyntro_web_prototype_v0_1.zip -d . && unzip -o elyntro_engine_v6_2_0.zip -d . && pip install -r requirements.txt`

Start command:
`PYTHONPATH=elyntro-engine-v6.2.0 gunicorn app:app`

Health check path: `/api/health`.

The free hosting tier can sleep and its filesystem may be ephemeral; this is a prototype, not production deployment. Do not put secrets in the repository. Do not use the demo with sensitive personal information.
