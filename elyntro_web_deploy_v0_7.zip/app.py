from __future__ import annotations
import os
import re
import html as html_escape
import json
import urllib.error
import urllib.request
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory
from elyntro import CognitiveLoop, EvidenceVerifier
from elyntro.contracts import TaskRequest
from elyntro.engine import Engine
from elyntro.memory import MemoryStore
from elyntro.planner import RuleBasedPlanner, ToolDefinition
from elyntro.store import SQLiteStore
from elyntro.task_executor import StepResult, TaskExecutor

BASE = Path(__file__).resolve().parent
DB_PATH = os.environ.get("ELYNTRO_DB_PATH", str(BASE / "elyntro.db"))
app = Flask(__name__, static_folder="static")
store = SQLiteStore(DB_PATH)
engine = Engine(store)

CRITERION = "Se ha creado un artefacto no vacío y comprobable"

def _goal_artifact(goal: str) -> dict:
    normalized = goal.casefold()
    safe_title = re.sub(r"[^\w\- ]", "", goal).strip()[:80] or "Proyecto Elyntro"
    escaped_title = html_escape.escape(safe_title)
    escaped_goal = html_escape.escape(goal.strip())
    if any(word in normalized for word in ("web", "página", "pagina", "html", "sitio")):
        content = f'''<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{escaped_title}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:760px;margin:12vh auto;padding:24px;line-height:1.6;background:#f7f4ee;color:#202522}}main{{border-left:5px solid #183b35;padding:24px}}h1{{color:#183b35}}</style></head>
<body><main><p>Elyntro · Prototipo</p><h1>{escaped_title}</h1><p>Objetivo recibido: {escaped_goal}</p><p>Esta es una primera estructura generada mediante una plantilla determinista. Aún no se ha conectado un modelo de IA para diseñar contenido de forma inteligente.</p></main></body></html>'''
        return {"name": "index.html", "content": content, "media_type": "text/html"}
    content = (f"# {safe_title}\n\n"
               "## Objetivo recibido\n\n" + goal.strip() + "\n\n"
               "## Estado del prototipo\n\n"
               "Este archivo se ha generado con una plantilla local determinista. El motor de tareas y la verificación están integrados, pero no hay todavía un proveedor de modelo de lenguaje conectado.\n")
    return {"name": "resultado.md", "content": content, "media_type": "text/markdown"}

def handle_research(inputs, context):
    goal = str(inputs.get("goal", ""))
    artifact = {"name": "alcance_de_investigacion.md",
                "content": ("# Alcance de investigación\n\n"
                            "Objetivo: " + goal + "\n\n"
                            "No se ha configurado un proveedor de búsqueda web; este paso no afirma haber consultado fuentes externas.\n"),
                "media_type": "text/markdown"}
    return StepResult(output={"external_research": "not_configured", "note": "No se consultaron fuentes externas."}, artifacts=[artifact])

def _groq_chat(goal: str, direct: bool = False) -> dict:
    """Call Groq chat completions. The API response, not model-generated text, is the source of model metadata."""
    api_key = os.environ.get("GROQ_API_KEY", "").strip()
    if not api_key:
        return {"configured": False, "text": None, "model": None, "error": "GROQ_API_KEY no está configurada."}
    model = os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b").strip()
    system_prompt = (
        "Eres Elyntro. Responde en español salvo que el usuario pida otro idioma. "
        "Sigue exactamente el formato y la extensión que pide el usuario. "
        "Si pide una respuesta breve o solo una palabra, devuelve únicamente eso; "
        "no añadas análisis, pasos, títulos ni comprobaciones. No inventes acciones ni fuentes."
        if direct else
        "Eres Elyntro, un asistente analítico. Responde en español, con precisión. "
        "Distingue hechos, inferencias y límites. No afirmes haber usado herramientas, "
        "fuentes externas o realizado acciones que no hayas realizado. Estructura la respuesta "
        "con objetivo, análisis, pasos y comprobaciones solo cuando sea útil."
    )
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": goal},
        ],
        "temperature": 0.2,
        "max_tokens": 300 if direct else 1200,
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions",
        data=payload,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "User-Agent": "Elyntro/0.6 (+https://github.com/JejeStudio-web/elyntro-prototype)"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as response:
            data = json.loads(response.read().decode("utf-8"))
        answer = data["choices"][0]["message"]["content"]
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError("empty response")
        # This value comes from Groq's API response, never from the model's prose.
        returned_model = data.get("model") if isinstance(data.get("model"), str) else None
        return {
            "configured": True, "text": answer.strip(),
            "model": returned_model or model, "requested_model": model,
            "response_id": data.get("id"), "usage": data.get("usage"), "error": None
        }
    except urllib.error.HTTPError as exc:
        # Preserve the provider's error body for diagnosis, without exposing secrets or headers.
        try:
            raw = exc.read(4096).decode("utf-8", errors="replace").strip()
        except Exception:
            raw = ""
        detail = None
        code = None
        kind = None
        if raw:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    err = parsed.get("error", parsed)
                    if isinstance(err, dict):
                        detail = err.get("message") or err.get("detail") or err.get("description")
                        code = err.get("code")
                        kind = err.get("type") or err.get("error_type")
                    elif isinstance(err, str):
                        detail = err
                elif isinstance(parsed, str):
                    detail = parsed
            except (ValueError, TypeError):
                pass
            if not detail:
                detail = raw
        detail = str(detail or "").replace(api_key, "[clave oculta]")
        detail = re.sub(r"(?i)(bearer\s+)[^\s,;]+", r"\1[oculto]", detail)
        detail = re.sub(r"(?i)(gsk_[A-Za-z0-9_-]{8,})", "[clave oculta]", detail)[:700]
        diagnostic = f"HTTP {exc.code}"
        if kind:
            diagnostic += f" · tipo: {kind}"
        if code:
            diagnostic += f" · código: {code}"
        if detail:
            diagnostic += f" · {detail}"
        else:
            diagnostic += " · Groq devolvió un cuerpo de error vacío."
        return {"configured": True, "text": None, "model": model, "requested_model": model, "error": diagnostic}
    except (urllib.error.URLError, TimeoutError):
        return {"configured": True, "text": None, "model": model, "requested_model": model, "error": "No se pudo conectar con Groq (conexión o tiempo de espera)."}
    except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError):
        return {"configured": True, "text": None, "model": model, "requested_model": model, "error": "La respuesta de Groq no tenía el formato esperado."}

def handle_analyze(inputs, context):
    goal = str(inputs.get("goal", ""))
    result = _groq_chat(goal)
    if result["text"]:
        content = {"goal": goal, "method": "groq-chat-completions", "external_model_used": True,
                   "provider": "groq", "model": result["model"], "analysis": result["text"],
                   "limitations": ["No se han consultado fuentes web externas", "La respuesta del modelo requiere evaluación independiente"]}
        summary = "Análisis generado por Groq (" + str(result["model"]) + "). No se ha realizado investigación web externa."
    else:
        content = {"goal": goal, "method": "deterministic-baseline", "external_model_used": False,
                   "provider": "groq", "model": result["model"], "provider_error": result["error"],
                   "limitations": ["No se ha podido obtener respuesta de Groq", "No se han consultado fuentes web externas"]}
        summary = "No se obtuvo respuesta del modelo: " + str(result["error"])
    artifact = {"name": "analisis_local.json", "content": content, "media_type": "application/json"}
    return StepResult(output={"analysis": summary, "external_model_used": bool(result["text"])}, artifacts=[artifact])

def handle_create(inputs, context):
    artifact = _goal_artifact(str(inputs.get("goal", "")))
    return StepResult(output={"created": artifact["name"], "mode": "deterministic-template"}, artifacts=[artifact])

def handle_verify(inputs, context):
    return StepResult(output={"verification_requested": True}, evidence=[{"criterion": CRITERION, "detail": "El artefacto debe existir y tener contenido no vacío; el validador independiente lo inspeccionará."}])

TOOLS = [
    ToolDefinition(key="research", description="Registrar el alcance y los límites de investigación", capabilities=("research",), max_retries=0),
    ToolDefinition(key="analyze", description="Analizar y registrar el objetivo localmente", capabilities=("analyze",), max_retries=0),
    ToolDefinition(key="create", description="Crear un artefacto inicial", capabilities=("create",), max_retries=0),
    ToolDefinition(key="verify", description="Solicitar comprobación independiente del artefacto", capabilities=("verify",), max_retries=0),
]
HANDLERS = {"research": handle_research, "analyze": handle_analyze, "create": handle_create, "verify": handle_verify}
verifier = EvidenceVerifier()
def validate_artifact(criterion, evidence, context):
    goal = str(context.get("goal", "")).casefold()
    artifacts = [item for item in context.get("artifacts", []) if isinstance(item, dict)]
    if any(word in goal for word in ("web", "página", "pagina", "html", "sitio")):
        expected = [a for a in artifacts if a.get("name") == "index.html"]
        return any(isinstance(a.get("content"), str) and "<!doctype html>" in a["content"].casefold() and "<html" in a["content"].casefold() for a in expected)
    if any(word in goal for word in ("analiza", "analizar", "análisis", "analisis", "evalúa", "evalua", "compara")):
        expected = [a for a in artifacts if a.get("name") == "analisis_local.json"]
        return any(isinstance(a.get("content"), dict) and a["content"].get("goal") == context.get("goal") for a in expected)
    expected = [a for a in artifacts if a.get("name") == "resultado.md"]
    return any(isinstance(a.get("content"), str) and a["content"].strip().startswith("# ") for a in expected)
verifier.register(CRITERION, validate_artifact)
executor = TaskExecutor(engine, handlers=HANDLERS, verifier=verifier)
loop = CognitiveLoop(engine, RuleBasedPlanner(), TOOLS, executor, verifier=verifier)

@app.get("/")
def home():
    return send_from_directory(app.static_folder, "index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "prototype": "0.7.0", "engine": "6.2.0", "model_provider": "groq_configured" if os.environ.get("GROQ_API_KEY", "").strip() else "not_configured", "model": os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b") if os.environ.get("GROQ_API_KEY", "").strip() else None, "external_research": "not_configured"})

@app.post("/api/chat")
def direct_chat():
    """Direct answer path: no planner, task executor, or artifact-verification step."""
    payload = request.get_json(silent=True) or {}
    goal = payload.get("goal")
    if not isinstance(goal, str) or not goal.strip():
        return jsonify({"error": "Escribe una petición no vacía."}), 400
    if len(goal) > 10000:
        return jsonify({"error": "La petición supera el límite de 10.000 caracteres."}), 400
    result = _groq_chat(goal.strip(), direct=True)
    if not result.get("text"):
        return jsonify({"ok": False, "error": result.get("error"), "provider": "groq",
                        "requested_model": result.get("requested_model")}), 502
    return jsonify({"ok": True, "answer": result["text"], "provider": "groq",
                    "requested_model": result.get("requested_model"),
                    "returned_model": result.get("model"), "response_id": result.get("response_id"),
                    "usage": result.get("usage"), "path": "direct-chat-no-planner"})


@app.post("/api/tasks")
def create_task():
    payload = request.get_json(silent=True) or {}
    goal = payload.get("goal")
    if not isinstance(goal, str) or not goal.strip():
        return jsonify({"error": "Escribe un objetivo no vacío."}), 400
    if len(goal) > 10000:
        return jsonify({"error": "El objetivo supera el límite de 10.000 caracteres."}), 400
    task_request = TaskRequest(goal=goal.strip(), constraints=["No afirmar que se han usado modelos o fuentes que no están configurados."], success_criteria=[CRITERION])
    result = loop.run(task_request, namespace="prototype")
    return jsonify({"task": result.task.to_dict(), "plan": [{"step_id": s.step_id, "name": s.name, "handler_key": s.handler_key} for s in result.plan.steps] if result.plan else [], "verification": result.verification, "plan_review": result.plan_review}), 201

@app.get("/api/tasks/<task_id>")
def get_task(task_id):
    try:
        task = store.get_task(task_id)
        events = store.list_events(task_id)
    except (KeyError, ValueError):
        return jsonify({"error": "Tarea no encontrada."}), 404
    return jsonify({"task": task.to_dict(), "events": events})

@app.get("/api/tasks/<task_id>/artifacts/<path:name>")
def get_artifact(task_id, name):
    try:
        task = store.get_task(task_id)
    except (KeyError, ValueError):
        return jsonify({"error": "Tarea no encontrada."}), 404
    for artifact in task.artifacts:
        if artifact.get("name") == name:
            content = artifact.get("content", "")
            if not isinstance(content, str):
                return jsonify({"artifact": artifact}), 200
            return app.response_class(content, mimetype=artifact.get("media_type", "text/plain"))
    return jsonify({"error": "Artefacto no encontrado."}), 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
