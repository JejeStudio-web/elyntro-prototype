import tempfile
import unittest
from pathlib import Path
from elyntro import CognitiveLoop, EvidenceVerifier
from elyntro.contracts import TaskRequest
from elyntro.engine import Engine
from elyntro.planner import RuleBasedPlanner, ToolDefinition
from elyntro.store import SQLiteStore
from elyntro.task_executor import StepResult, TaskExecutor

CRITERION = "Se ha creado un artefacto no vacío y comprobable"

def research(inputs, context):
    return StepResult(output={"external_research": "not_configured"}, artifacts=[{"name":"alcance_de_investigacion.md", "content":"# Alcance\nNo se consultaron fuentes externas.", "media_type":"text/markdown"}])
def analyze(inputs, context):
    goal = str(inputs.get("goal", ""))
    return StepResult(output={"analysis":"deterministic-baseline"}, artifacts=[{"name":"analisis_local.json", "content":{"goal":goal,"external_model_used":False}, "media_type":"application/json"}])
def create(inputs, context):
    goal = str(inputs.get("goal", ""))
    if any(w in goal.casefold() for w in ("web", "página", "pagina", "html", "sitio")):
        return StepResult(output={"created":"index.html"}, artifacts=[{"name":"index.html", "content":"<!doctype html><html lang=\"es\"><title>Test</title><body>Demo</body></html>", "media_type":"text/html"}])
    return StepResult(output={"created":"resultado.md"}, artifacts=[{"name":"resultado.md", "content":"# Resultado\n\n"+goal, "media_type":"text/markdown"}])
def verify(inputs, context):
    return StepResult(output={"verification_requested":True}, evidence=[{"criterion":CRITERION,"detail":"The independent validator checks the expected artifact for this goal."}])
def validator(criterion, evidence, context):
    goal = str(context.get("goal", "")).casefold()
    arts = [a for a in context.get("artifacts", []) if isinstance(a, dict)]
    if any(w in goal for w in ("web", "página", "pagina", "html", "sitio")):
        return any(a.get("name")=="index.html" and isinstance(a.get("content"),str) and "<!doctype html>" in a["content"].casefold() for a in arts)
    if any(w in goal for w in ("analiza", "analizar", "análisis", "analisis", "evalúa", "evalua", "compara")):
        return any(a.get("name")=="analisis_local.json" and isinstance(a.get("content"),dict) and a["content"].get("goal")==context.get("goal") for a in arts)
    return any(a.get("name")=="resultado.md" and isinstance(a.get("content"),str) and a["content"].strip().startswith("# ") for a in arts)

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.engine = Engine(SQLiteStore(str(Path(self.tmp.name)/"test.db")))
        self.tools = [ToolDefinition(key=k, description=k, capabilities=(k,), max_retries=0) for k in ("research","analyze","create","verify")]
        self.verifier = EvidenceVerifier(); self.verifier.register(CRITERION, validator)
        handlers={"research":research,"analyze":analyze,"create":create,"verify":verify}
        self.executor=TaskExecutor(self.engine, handlers=handlers, verifier=self.verifier)
        self.loop=CognitiveLoop(self.engine, RuleBasedPlanner(), self.tools, self.executor, verifier=self.verifier)
    def tearDown(self): self.tmp.cleanup()
    def test_web_artifact_verified(self):
        r=self.loop.run(TaskRequest(goal="Crea una página web de ciencias",success_criteria=[CRITERION]))
        self.assertEqual(r.task.status.value,"succeeded")
        self.assertTrue(any(a["name"]=="index.html" for a in r.task.artifacts))
        self.assertEqual(r.verification["status"],"verified")
    def test_analysis_artifact_verified(self):
        r=self.loop.run(TaskRequest(goal="Analiza mi idea de app",success_criteria=[CRITERION]))
        self.assertEqual(r.task.status.value,"succeeded")
        self.assertTrue(any(a["name"]=="analisis_local.json" for a in r.task.artifacts))
        self.assertEqual(r.verification["status"],"verified")
    def test_document_artifact_verified(self):
        r=self.loop.run(TaskRequest(goal="Escribe un documento sobre Elyntro",success_criteria=[CRITERION]))
        self.assertEqual(r.task.status.value,"succeeded")
        self.assertTrue(any(a["name"]=="resultado.md" for a in r.task.artifacts))
        self.assertEqual(r.verification["status"],"verified")
    def test_wrong_artifact_does_not_verify(self):
        self.assertFalse(validator(CRITERION, [], {"goal":"Crea una página web","artifacts":[{"name":"resultado.md","content":"# Not a web page"}]}))

if __name__ == "__main__": unittest.main(verbosity=2)


def test_direct_chat_bypasses_planner_and_returns_api_model(monkeypatch):
    import app as app_module
    monkeypatch.setattr(app_module, "_groq_chat", lambda goal, direct=False: {
        "configured": True, "text": "GROQ_OK openai/gpt-oss-20b", "model": "openai/gpt-oss-20b",
        "requested_model": "openai/gpt-oss-20b", "response_id": "resp_test", "usage": {"total_tokens": 8}, "error": None
    })
    client = app_module.app.test_client()
    response = client.post('/api/chat', json={"goal": "Responde únicamente GROQ_OK y el nombre del modelo"})
    assert response.status_code == 200
    body = response.get_json()
    assert body["path"] == "direct-chat-no-planner"
    assert body["returned_model"] == "openai/gpt-oss-20b"
    assert body["response_id"] == "resp_test"


def test_direct_chat_reports_provider_error(monkeypatch):
    import app as app_module
    monkeypatch.setattr(app_module, "_groq_chat", lambda goal, direct=False: {
        "configured": True, "text": None, "model": "openai/gpt-oss-20b",
        "requested_model": "openai/gpt-oss-20b", "error": "HTTP 403 · denied"
    })
    client = app_module.app.test_client()
    response = client.post('/api/chat', json={"goal": "Responde únicamente GROQ_OK"})
    assert response.status_code == 502
    assert response.get_json()["error"] == "HTTP 403 · denied"
