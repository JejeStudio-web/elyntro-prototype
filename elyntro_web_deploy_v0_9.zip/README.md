# Elyntro Web Prototype v0.9

## Cambios
- Enrutamiento de intención asistido por el modelo (JSON estructurado) con fallback explícito.
- Contexto conversacional reciente enviado desde la interfaz y limitado en el servidor.
- Búsqueda web de mejor esfuerzo mediante DuckDuckGo HTML para peticiones que el router clasifica como investigación.
- Respuestas que incorporan resultados recuperados y muestran enlaces de origen.
- Generación de archivos con contenido producido por el modelo y descarga desde la interfaz.
- Estados honestos: generación de un archivo no significa que haya sido ejecutado o probado; fuentes recuperadas no significan verificación exhaustiva.
- No se requiere seleccionar el tipo de tarea.

## Requisitos
- Python 3.11+
- `GROQ_API_KEY` configurada como variable secreta en Render.
- `GROQ_MODEL` es opcional; por defecto `openai/gpt-oss-20b`.

## Render
Build Command (comillas ASCII rectas):
```bash
python -c "import zipfile; zipfile.ZipFile('elyntro_web_deploy_v0_9.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt
```
Start Command:
```bash
PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app
```

## Limitaciones conocidas
- La búsqueda depende de que Render pueda acceder a DuckDuckGo; el HTML no es una API estable y puede bloquearse o cambiar. Si falla, Elyntro informa del límite y no inventa fuentes.
- No hay navegación profunda de páginas, extracción robusta de documentos, ejecución de código en sandbox, memoria persistente de usuario ni acciones en otras aplicaciones.
- El modelo puede equivocarse. La ruta y el contenido generados por el modelo no son pruebas de exactitud.
- No se debe subir `GROQ_API_KEY` al repositorio.
