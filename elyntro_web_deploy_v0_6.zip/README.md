# Elyntro Web Prototype 0.6.0

This is a minimal web shell around the supplied Elyntro Engine v6.2.0. It uses the engine's CognitiveLoop, RuleBasedPlanner, registered handlers, SQLite task store, and independent EvidenceVerifier. Groq chat completions are used for the analyze handler when GROQ_API_KEY is configured. If the key is absent or the provider fails, the app records the failure and falls back to a deterministic status artifact. Web search, image/audio/video generation, and computer-use providers remain unconnected. Set GROQ_MODEL optionally; default: openai/gpt-oss-20b.

## Groq setup

Set `GROQ_API_KEY` in the hosting provider secret/environment settings. Never commit it to Git. Optional `GROQ_MODEL` defaults to `llama-3.3-70b-versatile`. The health endpoint reports whether the key is present, not whether the key is valid.

## Local run (Python 3.11+)

1. Extract `elyntro_web_deploy_v0_4.zip`.
2. Extract `elyntro_engine_v6_2_0.zip` into the same directory.
3. `pip install -r requirements.txt`
4. `PYTHONPATH=elyntro-engine-v6.2.0 python app.py`
5. Open `http://127.0.0.1:5000`.

## Render deployment from a Git repository containing only the outer ZIP

Build command:
`python -c "import zipfile; zipfile.ZipFile('elyntro_web_deploy_v0_4.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt`

Start command:
`PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app`

Health check path: `/api/health`.

The free hosting tier can sleep and its filesystem may be ephemeral; this is a prototype, not production deployment. Do not put secrets in the repository. Do not use the demo with sensitive personal information.


## Despliegue v0.4 en Render

Este ZIP contiene `app.py`, `requirements.txt`, `render.yaml`, `static/` y `elyntro_engine_v6_2_0.zip` en la raíz. Para evitar que Render vuelva a extraer un ZIP anterior, configura el Build Command para extraer `elyntro_web_deploy_v0_3.zip` y después el ZIP del motor que está en la raíz del repositorio. La clave `GROQ_API_KEY` debe permanecer como variable secreta de entorno en Render.


## v0.4

- Default model changed to `openai/gpt-oss-20b`; override with `GROQ_MODEL` if needed.
- Groq HTTP errors now include sanitized provider diagnostic details in `analisis_local.json`.
- The web interface shows the actual model response or the provider error inline.


## v0.5.0

Mejora el diagnóstico de errores HTTP del proveedor: conserva el cuerpo de error de Groq cuando sea posible y lo sanitiza para ocultar claves. No registra ni muestra cabeceras de autorización.


## v0.6.0

- Adds an explicit, descriptive User-Agent to outbound Groq requests. This addresses a possible cause of Cloudflare HTTP 403 error 1010 associated with the default Python urllib client signature. It does not bypass Cloudflare or guarantee that Groq will accept the request.
