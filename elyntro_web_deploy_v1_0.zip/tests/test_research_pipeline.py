from __future__ import annotations
import json
import sys
import pytest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# These tests require the same Flask dependency installed by Render.
try:
    import app as elyntro_app
except ModuleNotFoundError as exc:
    if exc.name == "flask":
        elyntro_app = None
    else:
        raise


def test_artifact_validator_json():
    if elyntro_app is None:
        pytest.skip("Flask no está instalado en el entorno de construcción")
    result = elyntro_app._validate_artifact({"name": "data.json", "media_type": "application/json", "content": json.dumps({"ok": True})})
    assert result["status"] == "static_checks_passed"
    assert all(check["passed"] for check in result["checks"])


def test_artifact_validator_rejects_invalid_json():
    if elyntro_app is None:
        pytest.skip("Flask no está instalado en el entorno de construcción")
    result = elyntro_app._validate_artifact({"name": "data.json", "media_type": "application/json", "content": "{broken"})
    assert result["status"] == "static_checks_failed"


def test_artifact_validator_python_syntax_without_execution():
    if elyntro_app is None:
        pytest.skip("Flask no está instalado en el entorno de construcción")
    good = elyntro_app._validate_artifact({"name": "main.py", "media_type": "text/x-python", "content": "def main():\n    return 3\n"})
    bad = elyntro_app._validate_artifact({"name": "main.py", "media_type": "text/x-python", "content": "def :\n"})
    assert good["status"] == "static_checks_passed"
    assert bad["status"] == "static_checks_failed"


def test_local_urls_are_not_public_fetch_targets():
    if elyntro_app is None:
        pytest.skip("Flask no está instalado en el entorno de construcción")
    assert not elyntro_app._public_http_url("http://127.0.0.1/admin")
    assert not elyntro_app._public_http_url("file:///etc/passwd")
    assert not elyntro_app._public_http_url("http://localhost/")


def test_html_extractor_skips_script_and_navigation():
    if elyntro_app is None:
        pytest.skip("Flask no está instalado en el entorno de construcción")
    parser = elyntro_app._ReadableHTML()
    parser.feed("<html><body><nav>MENU</nav><main>Useful page content</main><script>bad()</script></body></html>")
    extracted = " ".join(parser.parts)
    assert "Useful page content" in extracted
    assert "MENU" not in extracted
    assert "bad()" not in extracted
