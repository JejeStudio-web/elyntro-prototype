# Elyntro Web Prototype v1.0 — Research & Verification

## Cambios principales respecto a v0.9
- **Investigación multi-consulta:** el modelo propone consultas complementarias; el sistema deduplica resultados y conserva la trazabilidad de las consultas.
- **Lectura de páginas públicas:** intenta recuperar y extraer texto de hasta ocho resultados web, además de conservar fragmentos de búsqueda cuando no se puede leer la página.
- **Revisión de respaldo:** una segunda llamada al modelo busca afirmaciones sin respaldo, matices omitidos y conflictos entre fuentes. Es una revisión automática, no una prueba independiente de verdad.
- **Validación estática de artefactos:** JSON se parsea; HTML comprueba estructura básica; Python se compila sin ejecutarse. Se muestran comprobaciones y límites en la interfaz.
- **Protección básica de recuperación:** solo intenta HTTP(S) público y rechaza destinos locales/privados obvios; no es una garantía de seguridad completa contra todos los redireccionamientos o cambios DNS.
- **UI de transparencia ampliada:** muestra nivel de recuperación, páginas leídas, estado de revisión y fallos de validación estática.
- **No ejecuta código generado**, no afirma que un archivo funcione por pasar comprobaciones estáticas y no presenta la revisión del modelo como verificación independiente.

## Requisitos
- Python 3.11+
- `GROQ_API_KEY` como variable secreta de Render.
- `GROQ_MODEL` opcional; valor predeterminado `openai/gpt-oss-20b`.
- `Flask` y `gunicorn` se instalan desde `requirements.txt`.

## GitHub y Render
1. Sube `elyntro_web_deploy_v1_0.zip` a la raíz del repositorio junto a `elyntro_engine_v6_2_0.zip`.
2. Build Command (comillas ASCII rectas):
```bash
python -c "import zipfile; zipfile.ZipFile('elyntro_web_deploy_v1_0.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt
```
3. Start Command:
```bash
PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app
```
4. Mantén `GROQ_API_KEY` en Render, nunca en GitHub.

## Qué significa “verificado” en v1.0
- La respuesta de investigación puede ser revisada frente al texto recuperado, pero el propio modelo realiza la revisión. No es verificación independiente.
- Las comprobaciones de artefactos son estáticas; no se ejecutan ni prueban en un sandbox.
- El buscador DuckDuckGo HTML es una integración de mejor esfuerzo y puede bloquearse o cambiar.
- El contexto conversacional sigue llegando desde el navegador; no es memoria persistente entre dispositivos o sesiones.
- No hay todavía un runtime general de herramientas, navegación autenticada, memoria persistente robusta, ni equivalencia con ChatGPT/Perplexity.

## Pruebas
```bash
python -m compileall -q app.py tests
pytest -q
```
Las pruebas de integración del motor requieren las dependencias incluidas en Render y la extracción del ZIP del motor. Las pruebas de red dependen del acceso del entorno a DuckDuckGo y páginas públicas; no se consideran una garantía de disponibilidad.
