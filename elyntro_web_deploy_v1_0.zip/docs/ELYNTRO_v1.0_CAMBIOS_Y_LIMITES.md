# Elyntro v1.0 — Cambios de arquitectura y siguiente objetivo

## Diagnóstico de v0.9
v0.9 podía clasificar la intención, consultar resultados de búsqueda, generar archivos y reutilizar historial enviado por el navegador. Sin embargo, investigación equivalía principalmente a fragmentos de buscador: no leía de forma sistemática las páginas ni evaluaba si la respuesta estaba realmente respaldada. Los artefactos se consideraban presentes, pero no había validación por formato. El contexto era efímero y la revisión de la respuesta no existía.

## Cambios funcionales incluidos en v1.0
1. **Recuperación de varias consultas:** solicita consultas complementarias al modelo y las deduplica.
2. **Lectura de páginas:** descarga páginas HTTP(S) públicas, extrae texto útil y limita el tamaño por página y el número de fuentes.
3. **Evidencia más rica:** la respuesta recibe contenido de páginas y no únicamente títulos o snippets; se conservan enlaces rastreables.
4. **Revisión de respaldo en segunda pasada:** otro turno del modelo busca afirmaciones no respaldadas, matices ausentes y contradicciones. Se informa claramente que esto no es una verificación independiente.
5. **Validación estática por formato:** análisis JSON, estructura HTML básica y compilación sintáctica Python sin ejecutar el contenido.
6. **Protección básica de URLs:** rechaza esquemas no HTTP(S), loopback, dominios locales y direcciones no globales obvias. La recuperación sigue necesitando endurecimiento frente a redirecciones/DNS rebinding.
7. **UI explicativa:** expone nivel de recuperación, páginas leídas, estado de revisión y comprobaciones estáticas.
8. **Pruebas nuevas:** cubren extracción HTML, rechazo de destinos locales y validación de artefactos.

## Qué no afirma esta versión
- No iguala la capacidad de ChatGPT o Perplexity.
- No demuestra que una fuente diga la verdad solo por recuperarla.
- No ejecuta programas generados, no navega en sesiones autenticadas y no opera otras aplicaciones.
- No añade memoria persistente de usuario: el historial sigue viniendo del cliente.
- DuckDuckGo HTML puede bloquearse o cambiar, y la lectura de algunas páginas fallará.
- La revisión del modelo no sustituye una fuente primaria, un test automatizado ni un revisor independiente.

## Próximos bloques grandes recomendados
**v1.1 — runtime de herramientas:** contratos de herramientas, permisos, timeouts, límites, resultados estructurados y registros de ejecución; empezar por calculadora, lector de archivos y herramientas puramente locales.

**v1.2 — memoria de conversación fiable:** almacenamiento explícito y por sesión/usuario, resumen de contexto, recuperación por relevancia, caducidad y controles para ver/borrar; nunca guardar secretos de forma implícita.

**v1.3 — evaluación y calidad:** conjunto de pruebas de tareas reales, evaluación de citas, recuperación, seguimiento de instrucciones y regresiones por modelo; comparar versiones antes de desplegar.

**v1.4 — ejecución segura de artefactos:** sandbox aislado, límites de CPU/memoria/tiempo, sin red por defecto, pruebas unitarias generadas y resultados de test visibles.

La calidad debe medirse con tareas de evaluación repetibles. Más tokens o respuestas más largas no son un indicador suficiente de inteligencia.
