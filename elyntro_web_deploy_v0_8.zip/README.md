# Elyntro Web Prototype 0.8.0

Interfaz de entrada única y API de enrutamiento automático. El servidor clasifica peticiones sencillas entre respuesta conversacional y tareas de creación, análisis o investigación. Las respuestas conversacionales y el análisis usan Groq si `GROQ_API_KEY` está configurada. Las tareas siguen usando `CognitiveLoop`, `RuleBasedPlanner`, handlers y `EvidenceVerifier` del motor 6.2.0.

## Capacidades y límites reales
- No hay selector de tipo de tarea en la interfaz.
- Enrutamiento inicial basado en reglas explícitas, no en un clasificador semántico avanzado.
- Las respuestas de chat proceden de Groq, pero no se verifican factual e independientemente.
- La creación de archivos sigue usando plantillas deterministas para algunos tipos de artefacto.
- La búsqueda web, herramientas externas, uso del ordenador y generación multimedia no están conectados.
- El estado `verified` se limita a la validación local del artefacto configurado; no prueba que el objetivo general sea correcto.

## Variables de entorno
Configura `GROQ_API_KEY` como secreto en Render. Opcional: `GROQ_MODEL` (por defecto `openai/gpt-oss-20b`). No guardes la clave en GitHub.

## Render
Si subes el ZIP exterior al repositorio junto con `elyntro_engine_v6_2_0.zip`, configura Build Command así (comillas rectas):

```sh
python -c "import zipfile; zipfile.ZipFile('elyntro_web_deploy_v0_8.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt
```

Start Command:

```sh
PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app
```

Health check path: `/api/health`. La capa gratuita puede suspender el servicio y su disco puede ser efímero.
