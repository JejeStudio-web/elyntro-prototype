# Elyntro v1.1 — Runtime de herramientas y ciclo de ejecución verificable

## Objetivo
La v1.1 incorpora un runtime iterativo con herramientas explícitamente permitidas. El modelo puede solicitar una acción, recibir el resultado observado y continuar o producir una respuesta final. El bucle está limitado a seis pasos y no tiene acceso arbitrario al sistema operativo.

## Flujo
1. Recibir objetivo e historial reciente.
2. Pedir al modelo una decisión estructurada JSON.
3. Validar la acción y el nombre de herramienta contra una lista permitida.
4. Ejecutar una herramienta con límites de entrada y registrar el resultado.
5. Incorporar el resultado al contexto como datos no confiables.
6. Repetir hasta respuesta final, error del proveedor o límite de pasos.
7. Devolver respuesta, eventos observables, metadatos del proveedor y estado de verificación.

## Herramientas permitidas
- `web_search`: consulta resultados públicos de DuckDuckGo HTML cuando está disponible.
- `read_page`: extrae texto legible de una URL pública HTTP(S), con comprobaciones preliminares de destino.
- `calculate`: calcula expresiones aritméticas mediante un evaluador AST restringido; no usa `eval` ni ejecuta Python generado.
- `create_artifact`: pide al modelo un archivo estructurado y aplica validaciones estáticas por formato.

No existe ejecución general de código generado, control de navegador autenticado, modificación arbitraria de archivos, ni escritura en servicios externos.

## Ciclo de verificación
El sistema conserva eventos con herramienta, estado, resumen y evidencia observada. Para artefactos devuelve resultados de comprobaciones estáticas. La respuesta nunca se etiqueta como verdad verificada solo porque el modelo lo afirme. `tool_evidence_recorded_not_truth_verified` significa exactamente eso: hay registros de ejecución, pero no demuestra por sí mismo la verdad factual ni el cumplimiento total del objetivo.

## Límites de ejecución
- Máximo de seis iteraciones del modelo por petición.
- Lista permitida de herramientas; nombres desconocidos se rechazan.
- Argumentos JSON deben ser objetos.
- Salidas de herramientas se tratan como datos no confiables y no como instrucciones.
- Calculadora con gramática aritmética restringida, límites de magnitud y sin ejecución dinámica.
- La lectura web es best-effort y depende de disponibilidad del buscador, DNS y sitio remoto.
- La protección SSRF es una mitigación inicial, no una garantía de seguridad frente a todos los ataques de redirección o DNS rebinding.
- La validación de archivos es estática; no demuestra corrección funcional ni seguridad.

## Pruebas añadidas
- Ejecución de herramienta permitida y continuación hasta respuesta final.
- Rechazo de herramienta no autorizada.
- Límite de pasos produce estado incompleto, nunca éxito falso.
- Rechazo de código arbitrario en la calculadora.

## Despliegue
Sube `elyntro_web_deploy_v1_1.zip` a la raíz del repositorio y conserva `elyntro_engine_v6_2_0.zip` dentro del repositorio (también se incluye en el paquete). Usa el Build Command y Start Command indicados en el README del ZIP. Mantén `GROQ_API_KEY` solo en las variables secretas de Render.

## No incluido todavía
Memoria persistente de largo plazo con políticas de privacidad, sandbox de código, autenticación, permisos por usuario, navegador de computadora, fuentes con puntuación de autoridad, evaluación factual independiente ni benchmarks comparativos contra ChatGPT/Perplexity. Esos bloques requieren diseño, implementación y pruebas separadas.


## Resultado de validación en este entorno
- `python -m py_compile app.py tool_runtime.py`: correcto.
- `node --check` sobre el JavaScript integrado: correcto.
- `pytest -q tests/test_tool_runtime.py`: 4 pruebas aprobadas.
- No se ha ejecutado una prueba HTTP real contra Groq ni una prueba de despliegue en Render desde este entorno.
