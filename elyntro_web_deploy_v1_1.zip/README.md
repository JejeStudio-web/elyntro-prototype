# Elyntro v1.1 — runtime de herramientas

Esta versión conecta la entrada principal con un ciclo de ejecución iterativo y un conjunto acotado de herramientas. No es una equivalencia con ChatGPT o Perplexity y no afirma que los resultados estén verificados independientemente.

## Herramientas
- `web_search`: búsqueda pública best-effort.
- `read_page`: lectura de páginas HTTP(S) públicas.
- `calculate`: aritmética restringida sin `eval`.
- `create_artifact`: generación de archivo mediante Groq y validaciones estáticas.

Cada ejecución devuelve eventos, resultados y límites explícitos. El runtime tiene un máximo de seis pasos y rechaza herramientas no permitidas.

## Render
Build Command (comillas ASCII rectas):

```bash
python -c "import zipfile; zipfile.ZipFile('elyntro_web_deploy_v1_1.zip').extractall('.')" && python -c "import zipfile; zipfile.ZipFile('elyntro_engine_v6_2_0.zip').extractall('.')" && pip install -r requirements.txt
```

Start Command:

```bash
PYTHONPATH=elyntro-engine-v6.2.0 gunicorn --bind 0.0.0.0:$PORT app:app
```

Configura `GROQ_API_KEY` como variable secreta en Render. No guardes la clave en GitHub.

## Pruebas locales
Instala dependencias de `requirements.txt` y ejecuta `pytest -q`. La suite del motor y de la aplicación puede requerir Flask y las dependencias del motor. Las pruebas de `tool_runtime.py` no requieren Flask.

## Estado de verificación
La evidencia de ejecución confirma que una herramienta devolvió un resultado, no que todas las afirmaciones sean verdaderas. Los artefactos solo reciben validación estática; no se ejecuta código generado.
